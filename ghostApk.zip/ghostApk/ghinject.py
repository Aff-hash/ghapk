import os
import subprocess
import shutil

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APK_DIR = os.path.join(BASE_DIR, "apk")
OUT_DIR = os.path.join(BASE_DIR, "hasil")
DECOMPILE_DIR = os.path.join(BASE_DIR, "out")
DATA_DIR = os.path.join(BASE_DIR, "data")

def list_apk():
    os.makedirs(APK_DIR, exist_ok=True)
    os.makedirs(OUT_DIR, exist_ok=True)
    os.makedirs(DATA_DIR, exist_ok=True)

    files = [f for f in os.listdir(APK_DIR) if f.endswith(".apk")]
    if not files:
        print(f"[!] Tidak ada file.apk di folder {APK_DIR}/")
        print(" Masukkan APK target dulu.")
        input("Enter...")
        return None

    print("\nDaftar APK:")
    for i, f in enumerate(files, 1):
        size = os.path.getsize(os.path.join(APK_DIR, f)) // 1024
        print(f" {i}. {f} [{size} KB]")

    return files

def decompile_apk(apk_path):
    if os.path.exists(DECOMPILE_DIR):
        shutil.rmtree(DECOMPILE_DIR)
        print("[*] Hapus folder out/ lama")

    print(f"[*] Decompile {os.path.basename(apk_path)}...")
    cmd = f'apktool d "{apk_path}" -o "{DECOMPILE_DIR}" -f'

    result = subprocess.run(
        cmd,
        shell=True,
        capture_output=True,
        text=True
    )

    if result.returncode!= 0:
        print("[!] Gagal decompile:")
        print(result.stderr)
        return False

    print("[+] Decompile selesai!")
    return True

def ensure_target_path():
    target_path = os.path.join(DECOMPILE_DIR, "smali", "com", "os", "ram", "booster", "optimizer")

    if not os.path.exists(target_path):
        os.makedirs(target_path, exist_ok=True)
        print(f"[+] Buat folder: {target_path}")
    else:
        print(f"[+] Folder sudah ada: {target_path}")

    return target_path

def start_inject():
    os.system("clear" if os.name!= "nt" else "cls")
    print("=== GhostInject ===")

    files = list_apk()
    if not files:
        return

    try:
        idx = int(input("\nPilih nomor APK: ")) - 1
        if idx < 0 or idx >= len(files):
            print("Nomor salah!")
            input("Enter...")
            return
    except ValueError:
        print("Input harus angka!")
        input("Enter...")
        return

    selected_apk = os.path.join(APK_DIR, files[idx])

    if decompile_apk(selected_apk):
        print(f"\n[+] Hasil decompile ada di folder {DECOMPILE_DIR}/")
        target_smali_path = ensure_target_path()
        print(f"[*] Langkah selanjutnya: inject file dari folder data/ ke {target_smali_path}")
        input("Enter untuk kembali ke menu...")

    from main import menu
    menu()