import subprocess
import shutil
import os
import sys

VERSION = "0.1.0"

def run_cmd(cmd):
    try:
        out = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, text=True)
        return out.strip()
    except subprocess.CalledProcessError:
        return None

def check_deps():
    print("[*] Cek dependensi...")

    # Cek Java
    java_ver = run_cmd("java -version 2>&1 | head -n 1")
    if not java_ver:
        print("[!] Java tidak ditemukan!")
        print(" Install: pkg install openjdk-17 # Termux")
        print(" sudo apt install openjdk-17-jdk # Debian/Ubuntu")
        sys.exit(1)
    print(f"[+] Java: {java_ver}")

    # Cek apktool
    apktool_ver = run_cmd("apktool --version")
    if not apktool_ver:
        print("[!] apktool tidak ditemukan!")
        print(" Install: pkg install apktool # Termux")
        print(" atau download dari https://ibotpeaches.github.io/Apktool/")
        sys.exit(1)
    print(f"[+] Apktool: v{apktool_ver}")
    print()

def menu():
    os.system("clear" if os.name!= "nt" else "cls")
    print(f"=== GhostApk v{VERSION} ===")
    print("1.) GhostInject")
    print("2.) Help")
    print("q.) Exit/Quit")
    print("=" * 24)

    choice = input("Pilih menu: ").strip().lower()

    if choice == "1":
        from ghinject import start_inject
        start_inject()
    elif choice == "2":
        print("\nGhostInject: Decompile APK, inject file dari folder data/, lalu zip hasil.")
        print("Letakkan APK target di folder /apk")
        print("Letakkan file.smali yang mau disuntik di folder /data")
        input("\nEnter untuk kembali...")
        menu()
    elif choice == "q":
        print("Bye.")
        sys.exit(0)
    else:
        print("Pilihan tidak valid!")
        input("Enter...")
        menu()

if __name__ == "__main__":
    check_deps()
    menu()